const mysql = require('mysql')
const connection = mysql.createConnection({
  host: 'localhost',
  user: 'root',
  password: 'password',
  database: 'car_shop',
  //port: 7000
})

const Execute = async function (query) {
  return new Promise((res, rej) => {
    connection.query(query, (err, rows, fields) => {
      if (err) rej(err);
      else res(rows);
    })
  })
}

module.exports = { Execute };