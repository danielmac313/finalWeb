
SET SQL_MODE = "NO_AUTO_VALUE_ON_ZERO";
START TRANSACTION;
SET time_zone = "+00:00";


/*!40101 SET @OLD_CHARACTER_SET_CLIENT=@@CHARACTER_SET_CLIENT */;
/*!40101 SET @OLD_CHARACTER_SET_RESULTS=@@CHARACTER_SET_RESULTS */;
/*!40101 SET @OLD_COLLATION_CONNECTION=@@COLLATION_CONNECTION */;
/*!40101 SET NAMES utf8mb4 */;

--
-- Database: `car_shop`
--

-- --------------------------------------------------------

--
-- Table structure for table `cars`
--

CREATE TABLE `cars` (
  `Id` int(11) NOT NULL,
  `Name` varchar(255) NOT NULL,
  `Price` varchar(255) DEFAULT NULL,
  `ExteriorColor` varchar(255) DEFAULT NULL,
  `InteriorColor` varchar(255) DEFAULT NULL,
  `Drivetrain` varchar(255) DEFAULT NULL,
  `MPG` varchar(255) DEFAULT NULL,
  `FuelType` varchar(255) DEFAULT NULL,
  `Transmission` varchar(255) DEFAULT NULL,
  `Engine` varchar(255) DEFAULT NULL,
  `VIN` varchar(255) DEFAULT NULL,
  `StockNo` varchar(255) DEFAULT NULL,
  `Mileage` varchar(255) DEFAULT NULL,
  `image` varchar(45) DEFAULT NULL,
  `quantity` int(11) NOT NULL DEFAULT 0
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4;

--
-- Dumping data for table `cars`
--

INSERT INTO `cars` (`Id`, `Name`, `Price`, `ExteriorColor`, `InteriorColor`, `Drivetrain`, `MPG`, `FuelType`, `Transmission`, `Engine`, `VIN`, `StockNo`, `Mileage`, `image`, `quantity`) VALUES
(1, '2023 Ford Mustang EcoBoost', '34,995', 'Grabber Blue', 'Ebony', 'Rear-wheel Drive', '21–29', 'Gasoline', '6-Speed Manual', '2.3L I4 16V GDI DOHC Turbo', '1FA6P8TD2N5139968', '00F22094', '7 mi', '/public/car3.png', 3),
(2, '2024 Ford Mustang EcoBoost', '34,995', 'Grabber Blue', 'Ebony', 'Rear-wheel Drive', '21–29', 'Gasoline', '6-Speed Manual', '2.3L I4 16V GDI DOHC Turbo', '1FA6P8TD2N5139968', '00F22094', '7 mi', '/public/image.png', 2),
(3, '2025 Ford Mustang EcoBoost', '34,995', 'Grabber Blue', 'Ebony', 'Rear-wheel Drive', '21–29', 'Gasoline', '6-Speed Manual', '2.3L I4 16V GDI DOHC Turbo', '1FA6P8TD2N5139968', '00F22094', '7 mi', '/public/car2.webp', 5),
(4, '2026 Ford Mustang EcoBoost', '34,995', 'Grabber Blue', 'Ebony', 'Rear-wheel Drive', '21–29', 'Gasoline', '6-Speed Manual', '2.3L I4 16V GDI DOHC Turbo', '1FA6P8TD2N5139968', '00F22094', '7 mi', '/public/image.png', 4),
(5, '2027 Ford Mustang EcoBoost', '34,995', 'Grabber Blue', 'Ebony', 'Rear-wheel Drive', '21–29', 'Gasoline', '6-Speed Manual', '2.3L I4 16V GDI DOHC Turbo', '1FA6P8TD2N5139968', '00F22094', '7 mi', '/public/car3.png', 5);

-- --------------------------------------------------------

--
-- Table structure for table `cart`
--

CREATE TABLE `cart` (
  `id` int(11) NOT NULL,
  `car_id` int(11) DEFAULT NULL,
  `quantity` int(11) DEFAULT NULL,
  `iscomplete` tinyint(1) NOT NULL DEFAULT 0
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4;

--
-- Dumping data for table `cart`
--

INSERT INTO `cart` (`id`, `car_id`, `quantity`, `iscomplete`) VALUES
(1, 2, 2, 1),
(2, 3, 1, 1),
(3, 4, 2, 1),
(4, 2, 1, 1),
(7, 3, 1, 1),
(10, 3, 2, 1),
(13, 3, 2, 1);

-- --------------------------------------------------------

--
-- Table structure for table `car_rating`
--

CREATE TABLE `car_rating` (
  `id` int(11) NOT NULL,
  `carId` int(11) DEFAULT NULL,
  `rating` int(11) DEFAULT NULL
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4;

--
-- Dumping data for table `car_rating`
--

INSERT INTO `car_rating` (`id`, `carId`, `rating`) VALUES
(1, 2, 3),
(2, 1, 3);

-- --------------------------------------------------------

--
-- Table structure for table `car_reviews`
--

CREATE TABLE `car_reviews` (
  `id` int(11) NOT NULL,
  `carid` varchar(45) DEFAULT NULL,
  `review` varchar(5000) DEFAULT NULL
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4;

--
-- Dumping data for table `car_reviews`
--

INSERT INTO `car_reviews` (`id`, `carid`, `review`) VALUES
(1, '1', 'adsfadsfdas'),
(3, '2', 'adsfasdfadsasdfadsfasd'),
(4, '4', 'asdfadsfdas'),
(5, '1', 'adsfasdfsad'),
(6, '3', 'asdfdasfsda'),
(7, '2', 'asdfasd'),
(9, '2', 'Wow nice car'),
(10, '1', 'asdasd'),
(13, '5', 'Another Review');

--
-- Indexes for dumped tables
--

--
-- Indexes for table `cars`
--
ALTER TABLE `cars`
  ADD PRIMARY KEY (`Id`);

--
-- Indexes for table `cart`
--
ALTER TABLE `cart`
  ADD PRIMARY KEY (`id`);

--
-- Indexes for table `car_rating`
--
ALTER TABLE `car_rating`
  ADD PRIMARY KEY (`id`);

--
-- Indexes for table `car_reviews`
--
ALTER TABLE `car_reviews`
  ADD PRIMARY KEY (`id`);

--
-- AUTO_INCREMENT for dumped tables
--

--
-- AUTO_INCREMENT for table `cars`
--
ALTER TABLE `cars`
  MODIFY `Id` int(11) NOT NULL AUTO_INCREMENT, AUTO_INCREMENT=6;

--
-- AUTO_INCREMENT for table `cart`
--
ALTER TABLE `cart`
  MODIFY `id` int(11) NOT NULL AUTO_INCREMENT, AUTO_INCREMENT=14;

--
-- AUTO_INCREMENT for table `car_rating`
--
ALTER TABLE `car_rating`
  MODIFY `id` int(11) NOT NULL AUTO_INCREMENT, AUTO_INCREMENT=3;

--
-- AUTO_INCREMENT for table `car_reviews`
--
ALTER TABLE `car_reviews`
  MODIFY `id` int(11) NOT NULL AUTO_INCREMENT, AUTO_INCREMENT=14;
COMMIT;

/*!40101 SET CHARACTER_SET_CLIENT=@OLD_CHARACTER_SET_CLIENT */;
/*!40101 SET CHARACTER_SET_RESULTS=@OLD_CHARACTER_SET_RESULTS */;
/*!40101 SET COLLATION_CONNECTION=@OLD_COLLATION_CONNECTION */;
