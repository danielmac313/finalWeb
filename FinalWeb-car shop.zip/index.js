const express = require('express');
const serveIndex = require('serve-index');
const { Execute } = require('./helper/mysql');

const app = express();
var bodyParser = require('body-parser');

app.use(bodyParser.json());
app.use(bodyParser.urlencoded({ extended: true }));

app.use('/public', express.static('public'));
app.use('/public', serveIndex('public'));


app.use((req, res, next) => {
  console.log('Time: ', new Date().toLocaleString());
  next();
});

app.use('/request-type', (req, res, next) => {
  console.log('Request type: ', req.method);
  next();
});


app.get('/data', async (req, res, next) => {
  var data = await Execute('select *,(select count(id) from car_reviews where carid = cars.id) as totalReviews,(SELECT ifnull(round(sum(rating)/count(rating),2),0) FROM car_rating where carId = cars.id ) as rating from cars;');
  res.json(data);
});

app.get('/review', async (req, res, next) => {
  var data = await Execute(`SELECT t.*,t1.review, t1.id as reviewId FROM cars t right join car_reviews t1 on t.id = t1.carid`);
  res.json(data);
});

app.post('/review', async (req, res, next) => {
  var data = await Execute(`INSERT INTO \`car_reviews\`(\`carid\`,\`review\`)VALUES('${req.body.id}','${req.body.review}');`);
  res.json("Ok");
});

app.post('/cart', async (req, res, next) => {
  var data = await Execute(`INSERT INTO cart(car_Id,quantity)values('${req.body.id}','${req.body.quantiy}');`);
  var data = await Execute(`update cars set quantity = quantity - ${req.body.quantiy} where id = ${req.body.id}`);
  res.json("Ok");
});

app.get('/cart-data', async (req, res, next) => {
  var data = await Execute(`SELECT t.*,t1.quantity as qty,t1.id as cartId FROM cars t join cart t1 on t.id = t1.car_id and t1.iscomplete = 0;`);
  res.json(data);
});

app.get('/cart', async (req, res, next) => {
  res.sendFile(`${__dirname}/views/cart.html`);
});

app.post('/rate', async (req, res, next) => {
  var data = await Execute(`INSERT INTO car_rating(carId,rating)values('${req.body.id}','${req.body.rating}')`);
  res.json("Ok");
});

app.get('/', function (req, res) {
  res.sendFile(`${__dirname}/views/index.html`);
});

app.get('/reviews', function (req, res) {
  res.sendFile(`${__dirname}/views/reviews.html`);
});

app.post('/checkout', async (req, res, next) => {
  var data = await Execute(`update cart set iscomplete = 1 where id = ${req.body.cartId}`);
  res.json("Ok");
});

app.post('/cancel-checkout', async (req, res, next) => {
  var data = await Execute(`delete from cart where id = ${req.body.cartId}`);
  var data = await Execute(`update cars set quantity = quantity + ${req.body.quantity} where id = ${req.body.carId}`);
  res.json("Ok");
});

app.post('/delete-review', async (req, res, next) => {
  var data = await Execute(`delete from car_reviews where id = ${req.body.reviewId}`);
  res.json("Ok");
});

app.listen(3000, () => console.log('Example app is listening on port 3000.'));