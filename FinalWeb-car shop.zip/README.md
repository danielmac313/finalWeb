# Car Shop Web Project
This is an online car shop web project that allows users to view available cars, read reviews, and add cars to the cart and checkout.


## 🏁 Technology Stack
- Node JS
- MySQL
- HTML
- CSS


## ⌨️ Key Features
- Rate a car between 1 - 5
- Add to cart and checkout
- See list of cars 
- See a car
- Write a review
- Delete review
- See the results in DB


## 🖥️‍ Site Screens
- Home screen - The home page displays a list of available cars for sale. Each car is displayed with its image, name, price, and a "Add to Cart" button. Clicking the "Add to Cart" button will add the car to the user's cart.
- Cart screen - The reviews page displays a list of reviews from previous customers. Each review is displayed with the reviewer's name, rating, and comments.
- Review screen - The cart page displays the items currently in the user's cart. Each item is displayed with its image, name, price, and a "Remove" button. Clicking the "Remove" button will remove the item from the user's cart. The page also displays the total price of all items in the cart.


## 🏃‍ Local Installation
Clone this repository to your local machine.
Navigate to the project directory in your terminal.
Run npm install to install the project dependencies.
1. $npm i.
2. $npx nodemon.
3. The project will now be running on http://localhost:3000.


## Thanks and enjoy the application
Daniel Roei Machluf